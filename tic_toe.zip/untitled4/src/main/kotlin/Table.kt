import java.util.*

class Table(private val player1: Player, private var player2: Player) {
    private val table = Array(3) { Array(3) { Shape.NONE } }

    private val reader = Scanner(System.`in`)

    fun run() {
        var turn = player1
        drawTable()
        while (true) {
            getPosition(turn)
            turn = if (turn == player1) player2 else player1
            drawTable()
            if (winCheck()) return
        }
    }

    private fun drawTable() {
        table.forEachIndexed { row, shapes ->
            shapes.forEachIndexed { col, shape ->
                print(' ')
                ShapeDrawer.draw(shape)
                if (col != 2) print(" |")
            }
            println()
            if (row != 2) println("-----------")
        }
    }

    private fun getPosition(player: Player) {
        while (true) {
            print("${player.name}:")
            val pos = reader.nextInt()
            if (pos < 1 || pos > 9) {
                println("invalid")
                continue
            }
            val row = (pos - 1) / 3
            val col = (pos - 1) % 3
            if (table[row][col] != Shape.NONE) {
                println("taken")
                continue
            }
            table[row][col] = player.shape
            return
        }
    }

    private fun winCheck(): Boolean {
        table.forEach { row ->
            if (row[0] != Shape.NONE && row[0] == row[1] && row[1] == row[2]){
                printWinner(row[0])
                return true
            }
        }
        for (i in 0..2){
            if (table[0][i] != Shape.NONE && table[0][i] == table[1][i] && table[1][i] == table[2][i]){
                printWinner(table[0][i])
                return true
            }
        }
        if (table[0][0] != Shape.NONE && table[0][0] == table[1][1] && table[1][1] == table[2][2]){
            printWinner(table[0][0])
            return true
        }
        if (table[0][2] != Shape.NONE && table[0][2] == table[1][1] && table[1][1] == table[2][0]){
            printWinner(table[0][2])
            return true
        }
        return false
    }

    private fun printWinner(shape: Shape) {
        val winner = if (player1.shape == shape) player1 else player2
        println("${winner.name} has won!")
    }
}