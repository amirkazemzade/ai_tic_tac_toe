data class Player(
    val name: String,
    val shape: Shape,
)