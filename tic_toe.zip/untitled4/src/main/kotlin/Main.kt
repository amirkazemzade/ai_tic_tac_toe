import java.util.*

fun main(args: Array<String>) {
    val reader = Scanner(System.`in`)
    print("player 1 name with shape X: ")
    val name1 = reader.next()
    print("player 2 name with shape O: ")
    val name2 = reader.next()
    val table = Table(Player(name1, Shape.CROSS), Player(name2, Shape.CIRCLE))
    table.run()
}