fun main() {
    tableTest()
}

fun tableTest() {
    val stubPlayer1 = Player("ali", Shape.CROSS)
    val stubPlayer2 = Player("reza", Shape.CIRCLE)
    Table(stubPlayer1, stubPlayer2).run()
}